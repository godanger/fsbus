<?php !defined('_Amysql') && exit; ?>

</body>
</html>