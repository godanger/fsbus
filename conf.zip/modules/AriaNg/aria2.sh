#!/bin/bash
#####		一键安装aria2 + yaaw	#####
#####		Author:xiaoz.me			#####
#####		Update:2017-12-08		#####

aria2pid=$(pgrep 'aria2c')

case $1 in
	'start')
		nohup aria2c --conf-path=/root/.aria2/aria2.conf > /root/.aria2/aria2.log 2>&1 &
		exit
	;;
	'stop')
		kill -9 ${aria2pid}
	;;
	'restart')
		kill -9 ${aria2pid}
		nohup aria2c --conf-path=/root/.aria2/aria2.conf > /root/.aria2/aria2.log 2>&1 &
		exit;
	;;
	'status')
		if [ "$aria2pid" == "" ]
			then
				echo "Not running!"
			else
				echo "Is running,pid is ${aria2pid}"
		fi
	;;
	*)
		echo 'error'
		exit
	;;
esac