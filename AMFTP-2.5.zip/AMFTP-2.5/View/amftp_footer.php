<div id="footer" style="">

当前内存限制 ( 每次处理文件大小限制范围 ) <b> <?php echo $memory_limit;?> </b> ┊ <a href="./index.php?c=index&a=rmtmp" >清除缓存</a> ┊ <a href="./index.php?c=index&a=help" >使用帮助</a><br />

<br />
<br />
</div>

</body>
</html>