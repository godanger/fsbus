<?php include('amftp_header.php');?>

<div id="content" style="">
	<div id="<?php echo $notice_status;?>"><?php echo $notice;?> 	<a href="<?php echo $back;?>"> » 返回</a></div>
</div>

<div id="footer" style="">
Copyright © 2015 华的科技 <a href="https://amh.sh" target="_blank">amh.sh</a> 
All Rights Reserved AMFTP 2.5  <a href="./index.php?c=index&a=help" >使用帮助</a>
<br />
<br />
</div>

</body>
</html>