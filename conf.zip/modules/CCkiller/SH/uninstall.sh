#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
Base_Dir=/usr/local/cckiller;
	echo "Uninstalling cckiller...";
    echo;
    test -f /etc/init.d/cckiller && /etc/init.d/cckiller stop;
    echo; echo; echo -n "Deleting script files.....";
    if [ -e "$Base_Dir/cckiller" ]; then
        rm -f $Base_Dir/cckiller;
	rm -f /bin/cckiller;
        echo -n "..";
    fi;
    if [ -d "$Base_Dir" ]; then
        rm -rf $Base_Dir;
        echo -n "..";
    fi;
    echo "done";
    echo; echo -n "Deleting system service.....";
    if [ -e '/etc/init.d/cckiller' ]; then
        rm -f /etc/init.d/cckiller;
        echo -n "..";
    fi;
    echo "done";
    echo; echo "Uninstall Complete"; echo;