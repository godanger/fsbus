#!/bin/bash
nowdir=$(cd "$(dirname "$0")"; pwd)
for bcfile in `ls /home/backup/ | grep .tar.gz.amh`; do
        bcfn=`echo $bcfile|sed -r 's/(.*)(\..*)/\1/g'`
	if [ ! -f "/home/backup/${bcfn}.up" ]; then 
		echo "Uploading $bcfile";
        ${nowdir}/bpcs_uploader.php upload /home/backup/${bcfile} $bcfile;
        echo "Creating bcfile $bcfn.up";
        touch "/home/backup/$bcfn.up" 
    else
    	echo "Deleteing $bcfile";
    	rm -f /home/backup/${bcfile};
    	rm -f /home/backup/${bcfn}.up;
	fi
done;

